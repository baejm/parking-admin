module.exports = {
  transpileDependencies: ["vuetify"],
  devServer: {
   // overlay: false
 //  host: 'test_admin.sunil-ezp.com',
//
host: '0.0.0.0',
hot : true,
disableHostCheck: true,
   port : '3001'
  }
}
