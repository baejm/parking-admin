<template>
   <router-view></router-view> 
</template>
<script>
// import config from "../config.js"
export default {
  data() {
    return {      
        }      
  },
  methods: {
  },
  created() {   
  }
}
</script>
<style>

</style>
