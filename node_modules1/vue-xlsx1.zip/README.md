# XLSX Made easy

This vue Library is a vue wrapper for the excellent: [sheet-js](https://github.com/SheetJS/js-xlsx) The aim of this library is to provide an easy to use, well documented way to parse and create spreadsheets in vue.

## Documentation

Check out our documentation at [https://vue-xlsx.netlify.com/](https://vue-xlsx.netlify.com/)